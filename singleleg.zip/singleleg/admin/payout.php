<?php 
include("inc/connect.php");
include("inc/chkAuth.php");

$dt=date('Y-m-d');



$sql="SELECT SUM(inc_amt) as dailysum,user_id FROM `daily_income` WHERE inc_date='$dt' GROUP BY user_id";
$rs=mysqli_query($conn,$sql);


while($row=mysqli_fetch_array($rs))
		
		{

			$dailySum=$row['dailysum'];
			$id=$row['user_id'];


			$sql="select count(*) from payout where closing_date='$dt' and user_id='$id'";
			$cntDailyPay=ReturnAnyValue($conn,$sql);
			
			if($cntDailyPay>0)
		      {

		      	echo "All payouts updated !";
		      	die();

		      }

		      else

		      	{

					$sql="SELECT SUM(inc_amt) FROM `gen_income` WHERE inc_date='$dt' AND user_id=".$id;
					$directSum=ReturnAnyValue($conn,$sql);

					$amount=$dailySum+$directSum;



					$sql="SELECT pan_no FROM `kyc_detail` where user_id=".$id;
					$checkPan=ReturnAnyValue($conn,$sql);

					if($checkPan=== NULL)
					{
					  $sql="select * from settings where id=1";
					  $rssetting=mysqli_query($conn,$sql);
					  $rowsetting=mysqli_fetch_array($rssetting);
					  $tds=$rowsetting['tds_no_pan'];
					  $adminCharge=$rowsetting['admin_charge'];
					  
					}
					else
					{
					  $sql="select * from settings where id=1";
					  $rssetting=mysqli_query($conn,$sql);
					  $rowsetting=mysqli_fetch_array($rssetting);
					  $tds=$rowsetting['tds'];
					  $adminCharge=$rowsetting['admin_charge'];
					}

					$netAmount=$amount-($amount*($tds+$adminCharge)/100);

					
					$sql="select cur_bal from payout where user_id=".$id." order by pid DESC limit 1";
					$oldBal=ReturnAnyValue($conn,$sql);
					if($oldBal=="")
					{
						$oldBal=0;
					}
					$newBal=$oldBal+$netAmount;

					$sql="insert into payout(user_id,amount,closing_date,tds,admin_charge,net_amt,prev_bal,cur_bal) values('$id','$amount','$dt','$tds','$adminCharge','$netAmount','$oldBal','$newBal')";
						//:insert into payout(user_id,amount,closing_date,tds,admin_charge,net_amt) values('1','710','2020-05-31','','','710')
					

					if(mysqli_query($conn,$sql))
					    {
					    	$sql="UPDATE `daily_income` SET `status` = '2' WHERE inc_date='$dt' and user_id=".$id;
					    	mysqli_query($conn,$sql);
					    	

					    	$sql="UPDATE `gen_income` SET `status` = '2' WHERE inc_date='$dt' and user_id=".$id;
					    	mysqli_query($conn,$sql);
					    	
					        
					    }

					 else 
					    {
					        echo "error:".$sql."<br>".mysqli_error($conn);
					    }


			    }
		}
  

//Note :Send EMail to admin after payout calculation
?>