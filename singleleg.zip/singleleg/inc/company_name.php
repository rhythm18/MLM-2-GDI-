<?php

$companyName="MLM";
echo $companyName;
?>